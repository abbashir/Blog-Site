<div class="copyright">
	<div class="container">
		<p style="color: #fff;">© 2016 Business_Blog. All rights reserved</p>
	</div>
</div>