<div class="head-bottom">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="{{url('/')}}">Home</a></li>
            <li><a href="{{url('/category/laravel')}}">Laravel</a></li>
            <li><a href="{{url('/category/php')}}">PHP</a></li>
			<li><a href="{{url('/category/jquery')}}">JQUERY</a></li>
			<li><a href="{{url('/category/ajex')}}">AJAX</a></li>
			<li><a href="{{url('/category/html')}}">HTML & CSS</a></li>
			<li><a href="{{url('/category/general')}}">GENERAL</a></li>
			<li><a href="{{url('/category/service')}}">Free Service</a></li>
			<li><a href="{{url('/')}}">Portfolio</a></li>

          </ul>
        </div><!--/.nav-collapse -->
      </div>
    
</div>