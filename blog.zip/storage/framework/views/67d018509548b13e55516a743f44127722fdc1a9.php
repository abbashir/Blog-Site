    <?php echo e($postByid->id); ?>



**********************************



<?php $__env->startSection('title'); ?>
Create Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>

   <div class="row">
	    <div class="col-lg-12">
	        <div class="panel panel-default">
	            <div class="panel-heading">
	                Create Post
	            </div>
	            <div class="panel-body">
	                <div class="row">
	                    <div class="col-lg-12">
	<form role="form" method="POST" action="<?php echo e(url('/storePost')); ?>" enctype="multipart/form-data">
	                         <?php echo e(csrf_field()); ?>



      <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">

                <label>Post Title</label>
                <input class="form-control" name="title" value="<?php echo e(old('title')); ?>">
                <span class="text-danger"><?php echo e($errors->first('title')); ?> </span>
               
      </div>


      <div class="form-group <?php echo e($errors->has('sub_title') ? 'has-error' : ''); ?>">

	        <label>Sub Title</label>
	       <textarea name="sub_title"  class="form-control" rows="3" required="required"><?php echo e(old('post_body')); ?></textarea>
	       <span class="text-danger"><?php echo e($errors->first('sub_title')); ?> </span>

	   </div>


	                          
	                           
	  <div class="form-group <?php echo e($errors->has('photo') ? 'has-error' : ''); ?>">
	                                <label>photo</label>
	                                <input type="file" name="photo" >
                <span class="text-danger"><?php echo e($errors->first('photo')); ?> </span>

	   </div>


             
	    <div class="form-group <?php echo e($errors->has('post_body') ? 'has-error' : ''); ?>">

	        <label>Post Body</label>
	       <textarea name="post_body" id="input" class="ckeditor" rows="3" required="required"><?php echo e(old('post_body')); ?></textarea>
	       <span class="text-danger"><?php echo e($errors->first('post_body')); ?> </span>

	    </div>
	                         
	                           
	                        
         

	                          
	                            <button type="submit" name="post_btn" class="btn btn-default col-lg-offset-4">Submit Post</button>
	                           
	                        </form>
	                    </div>
	                    <!-- /.col-lg-6 (nested) -->
	                  
	                    <!-- /.col-lg-6 (nested) -->
	                </div>
	                <!-- /.row (nested) -->
	            </div>
	            <!-- /.panel-body -->
	        </div>
	        <!-- /.panel -->
	    </div>
                <!-- /.col-lg-12 -->
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>