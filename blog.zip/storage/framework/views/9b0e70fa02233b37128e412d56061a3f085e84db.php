<?php $__env->startSection('title'); ?>
Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>

<?php $m = Session::get('message') ?>
<?php if(@isset ($m)): ?>
<div class="alert alert-success no-border mb-2" role="alert">
    <strong>Well done!</strong> <?php echo e($m); ?>

  </div>
<?php endif; ?>

<!-- Trigger the modal with a button -->
      <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add Category</button>
      <br> <br>

      <div class="container">
 
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Category</h4>
        </div>
        
        <div class="modal-body"> 
          <?php echo Form::open(['url' => '/storeCategory']); ?> <!-- use collective laravel pac-->
     <div class="form-group <?php echo e($errors->has('category_name') ? 'has-error' : ''); ?>">

                 <?php echo e(Form::label('text', 'Category Name:')); ?>

                
                 <?php echo e(Form::text('category_name',$value=null,['class'=>'form-control','placeholder'=>'Enter Category Name','autofocus'])); ?>

         <span class="text-danger"><?php echo e($errors->first('category_name')); ?></span>

     </div>
      
        </div>

        
         <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" name="brand">Submit</button>
        </div>

      <?php echo Form::close(); ?>

    
      </div>
      
    </div>
  </div>
  
</div>

<!-- modal end -->

   <div class="row">
	    <div class="col-lg-8 col-lg-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List of category
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>category Name</th>
                                            <th>Action</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                <?php $i = 1; ?>
                               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>         
                                       
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($category->category); ?></td>

                        <td>

                          <a href="<?php echo e(url('/category/delete/'.$category->id)); ?>" class="btn btn-warning btn-circle" onclick="return confirm('Are you sure delete this category ?')">

                            <i class="fa fa-trash-o"></i>
                          </a>
                                             	
                       </td>

                       <td>
                         <a href="" class="btn btn-primary btn-circle">
                           <i class="fa fa-edit"></i>
                          </a>
                          
                        </td>
                                        </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
<?php $__env->stopSection(); ?>

    

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>