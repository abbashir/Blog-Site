<?php $__env->startSection('title'); ?>
Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>

<?php $m = Session::get('message') ?>
<?php if(@isset ($m)): ?>
<div class="alert alert-success no-border mb-2" role="alert">
    <strong>Well done!</strong> <?php echo e($m); ?>

  </div>
<?php endif; ?>


   <div class="row">
	    <div class="col-lg-10 col-lg-offset-1">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List of Post
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Post title</th>
                                            <th>Post Category</th>

                                            <th>Action</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                <?php $i = 1; ?>
                               <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>         
                                       
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($post->title); ?></td>
                                            <td><?php echo e($post->category); ?></td>


                        <td>
                             <a href="<?php echo e(url('/post/delete/'.$post->id)); ?>" class="btn btn-warning btn-circle" onclick="return confirm('Are you sure delete this post ?')">

                            <i class="fa fa-trash-o"></i>
                          </a>                  	
                       </td>

                       <td>
                           <a href="<?php echo e(url('/post/edit/'.$post->id)); ?>" class="btn btn-primary btn-circle">
                           <i class="fa fa-edit"></i>
                          </a>
                        </td>
                                        </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
<?php $__env->stopSection(); ?>

    

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>