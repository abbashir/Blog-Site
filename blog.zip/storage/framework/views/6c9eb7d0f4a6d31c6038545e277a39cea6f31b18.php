       <div class="blo-top">
					<div class="tech-btm">
					<h4 class="text-center">Recent Post</h4>
					<hr>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					  <li><a href="<?php echo e(url('/post/'.$category->title)); ?>" class="bbb">
					  	<?php echo e($category->title); ?>

					  </a></li><hr>  

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>
        </div>

				<div class="blo-top">
					<div class="tech-btm">
					<h4 class="text-center">Popular Post</h4>
					<hr>
					<?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					  <li><a href="<?php echo e(url('/post/'.$popular->title)); ?>" class="bbb">
					  	<?php echo e($popular->title); ?></a></li><hr>  

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>
				</div>


				



				<div class="blo-top">
					<div class="tech-btm">
					<h4>Sign up to our newsletter</h4>
					<p>Sign up here to get the latest post</p>
						<div class="name">
							<form>
								<input type="text" placeholder="Email" required="">
							</form>
						</div>	
						<div class="button">
							<form>
								<input type="submit" value="Subscribe">
							</form>
						</div>
							<div class="clearfix"> </div>
					</div>
				</div>

				
			