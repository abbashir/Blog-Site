<?php 
$date = '2018-06-03 12:00:00';

$date = Carbon\Carbon::parse($date); // now date is a carbon instance
$elapsed = $date->diffForHumans(Carbon::now());
echo $elapsed;
 ?>
   
     <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
     <?php echo e(Carbon\Carbon::parse($post->created_at)->format('Y-m-d')); ?><br>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     