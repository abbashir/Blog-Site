
    <?php 
    use Carbon\Carbon;
    $dt = Carbon::now();
     $dt->toFormattedDateString();
      echo $dt->toFormattedDateString();


     ?>