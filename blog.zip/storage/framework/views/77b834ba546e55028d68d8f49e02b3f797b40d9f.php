<div class="copyright">
	<div class="container">
		<p style="color: #fff;">
			&copy; <?php echo date('Y'); ?> Div solutions Ltd. All rights reserved | developed by Abdul Bashir
		</p>
	</div>
</div>